## KindTap Platform Library for Python 3.9+

#### This library currently supports generating a signed authorization header which is required to make requests to KindTap Platform APIs.

### Installation

`pip install git+https://github.com/KindTap/kindtap-platform-python.git#0.0.1`

### Example using requests

#### Important Notes

* the `host` and `x-kt-date` headers are required
* request body must be a string that matches exactly the body of the HTTP request

```Python
```

### Valid signature will allow request

```
```

### Invalid signature will block request

```
```
